#!/bin/zsh
cd "/Users/zainrahman/Downloads/FC Simulator worktrees/physical-character-v2/sandbox/visual/physchar2"
V2_KNEE_MODEL=v2k V2_ANKLE_NEUTRAL_K=0.13 node tools/vres_diag.mjs --human=V2-198-92 --side=L --hz=180 --ff=on --traj=C-L5 --base=float --turf=off --xswing='{"vffRate":"srAll"}' --out=/private/tmp/claude-501/-Users-zainrahman/8af3fa3f-f134-4178-b7ae-7855027dda6e/scratchpad/vres/r4/runs/T_V2-198-92_C-L5_180_sr.json.gz > /private/tmp/claude-501/-Users-zainrahman/8af3fa3f-f134-4178-b7ae-7855027dda6e/scratchpad/vres/r4/runs/T_V2-198-92_C-L5_180_sr.log 2>&1
