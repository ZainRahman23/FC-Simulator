#!/bin/zsh
cd "/Users/zainrahman/Downloads/FC Simulator worktrees/physical-character-v2/sandbox/visual/physchar2"
V2_KNEE_MODEL=v2k V2_ANKLE_NEUTRAL_K=0.13 node tools/vres_diag.mjs --human=V2-REF --side=L --hz=480 --ff=on --traj=H-T45 --base=float --turf=off --xswing={"vffRate":"srAll","vffPassive":true} --out=/private/tmp/claude-501/-Users-zainrahman/8af3fa3f-f134-4178-b7ae-7855027dda6e/scratchpad/vres/r2/runs/A_V2-REF_H-T45_480_vpsr.json.gz > /private/tmp/claude-501/-Users-zainrahman/8af3fa3f-f134-4178-b7ae-7855027dda6e/scratchpad/vres/r2/runs/A_V2-REF_H-T45_480_vpsr.log 2>&1
