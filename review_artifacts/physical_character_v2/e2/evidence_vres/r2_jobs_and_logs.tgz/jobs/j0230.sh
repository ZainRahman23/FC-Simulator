#!/bin/zsh
cd "/Users/zainrahman/Downloads/FC Simulator worktrees/physical-character-v2/sandbox/visual/physchar2"
V2_KNEE_MODEL=v2k V2_ANKLE_NEUTRAL_K=0.13 node tools/vres_diag.mjs --human=V2-165-62 --side=L --hz=240 --ff=on --traj=R-L --base=float --turf=off --xswing={"diagD1PelAcc":true} --out=/private/tmp/claude-501/-Users-zainrahman/8af3fa3f-f134-4178-b7ae-7855027dda6e/scratchpad/vres/r2/runs/C_V2-165-62_R-L_240_d1pa.json.gz > /private/tmp/claude-501/-Users-zainrahman/8af3fa3f-f134-4178-b7ae-7855027dda6e/scratchpad/vres/r2/runs/C_V2-165-62_R-L_240_d1pa.log 2>&1
