#!/bin/zsh
cd "/Users/zainrahman/Downloads/FC Simulator worktrees/physical-character-v2/sandbox/visual/physchar2"
V2_KNEE_MODEL=v2k V2_ANKLE_NEUTRAL_K=0.13 node tools/vres_diag.mjs --human=V2-198-92 --side=L --hz=180 --ff=on --traj=R-L --base=float --turf=on --post=sv2 --out=/private/tmp/claude-501/-Users-zainrahman/8af3fa3f-f134-4178-b7ae-7855027dda6e/scratchpad/vres/r2/runs/B_V2-198-92_R-L_180_base.json.gz > /private/tmp/claude-501/-Users-zainrahman/8af3fa3f-f134-4178-b7ae-7855027dda6e/scratchpad/vres/r2/runs/B_V2-198-92_R-L_180_base.log 2>&1
