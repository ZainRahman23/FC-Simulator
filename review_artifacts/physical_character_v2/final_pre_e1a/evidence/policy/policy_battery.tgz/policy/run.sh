#!/bin/zsh
cd "/Users/zainrahman/Downloads/FC Simulator worktrees/physical-character-v2/sandbox/visual/physchar2"
G=/private/tmp/claude-501/-Users-zainrahman/8af3fa3f-f134-4178-b7ae-7855027dda6e/scratchpad/c/policy
for k in 0 0.13; do for p in current ref b50 b35 d1 d2; do for b in V2-165-62 V2-175-70 V2-REF V2-190-85 V2-198-92 V2-long-legs V2-short-legs V1-matched; do for sc in Q PY4 PR8 SB TURN T1 T5 UR LIFT HO1 HO2 HO3; do echo "$k $p $b $sc"; done; done; done; done | xargs -P 9 -L 1 zsh -c 'V2_ANKLE_NEUTRAL_K=$0 nice node tools/twist_policy_battery.mjs --policy=$1 --human=$2 --scen=$3 '$G'/r_$0_$1_$2_$3.json > /dev/null 2>'$G'/err_$0_$1_$2_$3.log'
echo DONE > $G/done
