const PC = "/Users/zainrahman/Downloads/FC Simulator worktrees/physical-character-v2/sandbox/visual/physchar2";
const { loadJolt } = await import(PC + "/core/v2_jolt.js"), { generateSpec } = await import(PC + "/spec/v2_spec.js"), { VARIATION_SET } = await import(PC + "/spec/v2_human.js"), { G2Sim, pushScenario } = await import(PC + "/gates/v2_g2.js");
const J = await loadJolt(PC + "/vendor/jolt-physics.wasm-compat.js"), [human, dir, Jm, standS] = process.argv.slice(2), stand = JSON.parse(standS);
const spec = generateSpec(VARIATION_SET.find(h => h.id === human)), s = new G2Sim(J, spec, pushScenario(dir, +Jm), { stand }), C = s.ctrl, f = C.feet[1]; let p0 = null, prev = "";
while (s.tick()) { const t = s.n * s.dt, st = s.st[f], lf = C.lc.feet[1], pr = s.probeRows[1]; if (!p0) p0 = st.pos.slice();
  const line = `${lf.state.padEnd(11)} s ${lf.s.toFixed(2)} a ${lf.a.toFixed(2)}`; if ((s.n % 12 === 0 && t > 0.9 && t < 3.2) || line.split(" ")[0] !== prev) console.log(`${t.toFixed(3)} ${line} | dx ${((st.pos[0] - p0[0]) * 1000).toFixed(1)} dz ${((st.pos[2] - p0[2]) * 1000).toFixed(1)} y ${((st.pos[1] - p0[1]) * 1000).toFixed(1)} mm | v ${(Math.hypot(st.v[0], st.v[2]) * 1000).toFixed(0)} mm/s | Fz ${(pr ? pr.JyN : 0).toFixed(1)} | touch ${pr ? pr.pieces.filter(p => p.touch).length : 0}`); prev = lf.state; }
s.destroy();
