const PC = "/Users/zainrahman/Downloads/FC Simulator worktrees/physical-character-v2/sandbox/visual/physchar2";
const { loadJolt } = await import(PC + "/core/v2_jolt.js"), { unloadSim, unloadSpec } = await import(PC + "/gates/v2_unload.js"), { polyDist } = await import(PC + "/ctrl/v2_stand.js");
const J = await loadJolt(PC + "/vendor/jolt-physics.wasm-compat.js"); const [body, drop, ramp] = process.argv.slice(2);
const spec = unloadSpec(body), { s, nL, nS } = unloadSim(J, spec, { foot: "L", drop: +drop, r: 0, ramp: +ramp, flags: { ffLockedAxis: true }, end: 3 + +ramp + 3, suppressRelease: true }), C = s.ctrl;
while (s.tick()) { const t = s.n * s.dt; if (t < 4.4 || s.n % 48) continue; const I = C.info, P = I.polys ? I.polys[nS] : null; const d = P ? polyDist(P, I.p) : null;
  console.log(`${t.toFixed(2)} share(n) ${I.share[nL].toFixed(3)} | CoP target inside the STANCE foot's region by ${d != null ? (d * 1000).toFixed(1) : "—"} mm (polyDist sign: + inside?) | ξ inside stance region ${P ? (polyDist(P, [I.xi[0], I.xi[1]]) * 1000).toFixed(1) : "—"} mm`); }
s.destroy();
