// DIAGNOSTIC: 6-DOF account of the resting foot's "drift" after release (fast transfer): origin translation vs yaw / tilt rotation vs contact-point (CoP) motion.
import fs from "fs";
const PC = "/Users/zainrahman/Downloads/FC Simulator worktrees/physical-character-v2/sandbox/visual/physchar2";
const { loadJolt } = await import(PC + "/core/v2_jolt.js"), { unloadSim, unloadSpec } = await import(PC + "/gates/v2_unload.js"), { V, Q } = await import(PC + "/core/v2_math.js");
const J = await loadJolt(PC + "/vendor/jolt-physics.wasm-compat.js"), M = JSON.parse(fs.readFileSync(PC + "/../../../review_artifacts/physical_character_v2/touch_semantics/manifest.json"));
const id = process.argv[2], flags = process.argv[3] ? JSON.parse(process.argv[3]) : null, run0 = M.runs.find(r => r.id === id), run = flags ? { ...run0, flags } : run0;
const spec = unloadSpec(run.body), { s, nL } = unloadSim(J, spec, run), C = s.ctrl, f = C.feet[nL], D = 180 / Math.PI;
const yaw = (q) => { const v = Q.rot(q, [0, 0, 1]); return Math.atan2(v[0], v[2]) * D; }, tilt = (q) => Math.acos(Math.min(1, Q.rot(q, [0, 1, 0])[1])) * D;
let tRel = null, r0 = null, prev = "SUPPORT"; const out = [];
while (s.tick()) { const t = s.n * s.dt, lf = C.lc.feet[nL], st = s.st[f], pr = s.probeRows[nL]; if (tRel == null && prev === "SUPPORT" && lf.state !== "SUPPORT") tRel = t; prev = lf.state;
  if (tRel != null && !r0 && t >= tRel - 0.1) r0 = { p: st.pos.slice(), yaw: yaw(st.rot), tilt: tilt(st.rot), cop: pr && pr.cop ? pr.cop.slice() : null };
  if (r0 && t <= tRel + 0.7 && s.n % 6 === 0) { const cop = pr && pr.cop ? pr.cop : null, Jc = pr ? pr.Jc : [0, 0, 0];
    out.push(`${t.toFixed(3)} ${lf.state.padEnd(10)} Fz ${(Jc[1] / s.dt).toFixed(2).padStart(6)} Ft ${(Math.hypot(Jc[0], Jc[2]) / s.dt).toFixed(2)} util ${(Jc[1] > 0 ? Math.hypot(Jc[0], Jc[2]) / Jc[1] : 0).toFixed(2)} | origin dxz ${(Math.hypot(st.pos[0] - r0.p[0], st.pos[2] - r0.p[2]) * 1000).toFixed(3)} mm | dyaw ${(yaw(st.rot) - r0.yaw).toFixed(3)}° tilt ${tilt(st.rot).toFixed(3)}° | CoP dxz ${cop && r0.cop ? (Math.hypot(cop[0] - r0.cop[0], cop[2] - r0.cop[2]) * 1000).toFixed(2) : "—"} mm | pieces ${pr ? pr.pieces.filter(p => p.touch).length : 0}`); } }
console.log(id, JSON.stringify(run.flags), "tRel", tRel?.toFixed(3)); console.log(out.join("\n")); s.destroy();
