// DIAGNOSTIC: G2 lateral push — which foot "slips" ~20 mm, and is it translation of the contact point (slide) or rotation / airborne motion?
const PC = "/Users/zainrahman/Downloads/FC Simulator worktrees/physical-character-v2/sandbox/visual/physchar2";
const { loadJolt } = await import(PC + "/core/v2_jolt.js"), { generateSpec } = await import(PC + "/spec/v2_spec.js"), { VARIATION_SET } = await import(PC + "/spec/v2_human.js"), { G2Sim, pushScenario } = await import(PC + "/gates/v2_g2.js"), { Q } = await import(PC + "/core/v2_math.js");
const J = await loadJolt(PC + "/vendor/jolt-physics.wasm-compat.js"), [human, dir, Jm, standS] = process.argv.slice(2), stand = JSON.parse(standS), D = 180 / Math.PI;
const spec = generateSpec(VARIATION_SET.find(h => h.id === human)), s = new G2Sim(J, spec, pushScenario(dir, +Jm), { stand }), C = s.ctrl, FT = C.feet;
const yaw = (q) => { const v = Q.rot(q, [0, 0, 1]); return Math.atan2(v[0], v[2]) * D; };
let p0 = null, y0 = null; const acc = [0, 1].map(() => ({ max: 0, tMax: 0, slideMax: 0, cop0: null, airT: 0, states: new Set(), yawMax: 0 })); let prevCop = [null, null];
while (s.tick()) { const t = s.n * s.dt, st = s.st; if (!p0) { p0 = FT.map(f => st[f].pos.slice()); y0 = FT.map(f => yaw(st[f].rot)); }
  for (const n of [0, 1]) { const a = acc[n], d = Math.hypot(st[FT[n]].pos[0] - p0[n][0], st[FT[n]].pos[2] - p0[n][2]) * 1000; if (d > a.max) { a.max = d; a.tMax = t; } a.yawMax = Math.max(a.yawMax, Math.abs(yaw(st[FT[n]].rot) - y0[n]));
    const pr = s.probeRows && s.probeRows[n]; const touch = pr ? pr.pieces.filter(p => p.touch).length : 0; if (!touch) a.airT += s.dt;
    if (C.lc) a.states.add(C.lc.feet[n].state);
    // slide: horizontal motion of the CoP point while loaded (> 20 N) between consecutive ticks, accumulated
    if (pr && pr.cop && pr.JyN > 20) { if (prevCop[n]) a.slideMax += Math.hypot(pr.cop[0] - prevCop[n][0], pr.cop[2] - prevCop[n][2]) * 1000 * 0; prevCop[n] = pr.cop.slice(); } else prevCop[n] = null; } }
const g = s.g2summary(); console.log(`${human} ${dir} ${Jm} ${JSON.stringify(stand)} → ${g.outcome}`);
for (const n of [0, 1]) { const a = acc[n]; console.log(`  foot ${n ? "R" : "L"}: max origin displacement ${a.max.toFixed(2)} mm at ${a.tMax.toFixed(2)} s; final ${(Math.hypot(s.st[FT[n]].pos[0] - p0[n][0], s.st[FT[n]].pos[2] - p0[n][2]) * 1000).toFixed(2)} mm; yaw change max ${a.yawMax.toFixed(2)}°; untouched (airborne) time ${a.airT.toFixed(2)} s; lifecycle states ${[...a.states].join(",")}`); }
if (C.lc) console.log('  end states', C.lc.feet.map(f => f.state).join('/'), 'loads N', C.sense.Fz.map(x => x.toFixed(1)).join('/'), 'run s', (s.n*s.dt).toFixed(2)); s.destroy();
