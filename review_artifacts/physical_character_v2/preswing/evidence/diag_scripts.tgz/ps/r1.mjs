// DIAGNOSTIC (R1): the straight-leg rebound after a fast transfer — commanded share vs sensed load, COM lateral state, ξ, CoP command, pelvis roll / height, knee flexion.
const PC = "/Users/zainrahman/Downloads/FC Simulator worktrees/physical-character-v2/sandbox/visual/physchar2";
const { loadJolt } = await import(PC + "/core/v2_jolt.js"), { unloadSim, unloadSpec } = await import(PC + "/gates/v2_unload.js"), { Q } = await import(PC + "/core/v2_math.js");
const J = await loadJolt(PC + "/vendor/jolt-physics.wasm-compat.js");
const [body, drop, ramp, flagsS, every] = process.argv.slice(2), flags = JSON.parse(flagsS || "{}"), D = 180 / Math.PI;
const spec = unloadSpec(body), run = { foot: "L", drop: +drop, r: 0, ramp: +ramp, flags, end: 3 + +ramp + 4, suppressRelease: true }, { s, nL, nS } = unloadSim(J, spec, run), C = s.ctrl, W = C.M * 9.81;
const pel = spec.bodies.findIndex(b => b.name === "pelvis"), kn = ["knee_L", "knee_R"].map(n => spec.joints.findIndex(j => j.name === n));
const roll = (q) => { const u = Q.rot(q, [1, 0, 0]); return Math.asin(Math.max(-1, Math.min(1, u[1]))) * D; };
console.log(`${body} d${drop} ramp ${ramp} ${JSON.stringify(flags)} (release suppressed: residual measurement); W ${W.toFixed(0)} N; t | F_cmd(n) | Fz(n) | share req | COM x (mm, + = stance side) | v x | ξ x | CoP cmd x | pelvis roll ° | pelvis y err mm | knee flex L/R`);
while (s.tick()) { const t = s.n * s.dt; if (t < 3.5 || s.n % (+every || 24)) continue; const I = C.info, st = s.st, side = nS === 1 ? 1 : -1;
  const Fc = I.F ? I.F[nL][1] : null, rots = st.map(b => b.rot), kf = kn.map(k => s.P.anat(s.P.jd[k], s.P.qcs(s.P.jd[k], rots), "flex"));
  console.log(`${t.toFixed(2)} | ${Fc?.toFixed(1)} | ${C.sense.Fz[nL].toFixed(1)} | ${I.share ? I.share[nL].toFixed(3) : "—"} | ${(I.c[0] * 1000 * side).toFixed(1)} | ${(I.v[0] * 1000 * side).toFixed(1)} | ${(I.xi[0] * 1000 * side).toFixed(1)} | ${(I.p[0] * 1000 * side).toFixed(1)} | ${roll(st[pel].rot).toFixed(3)} | ${((st[pel].pos[1] - C.pelHT) * 1000).toFixed(2)} | ${kf.map(x => (x * 1).toFixed(1)).join("/")}`); }
s.destroy();
