#!/bin/zsh
cd "/Users/zainrahman/Downloads/FC Simulator worktrees/physical-character-v2/sandbox/visual/physchar2"
V2_KNEE_MODEL=v2k V2_ANKLE_NEUTRAL_K=0.13 node tools/boundary_probe.mjs --human=V2-175-70 --F=30 --stand='{"lifecycle":true,"ikRefTwist":true,"ffLockedAxis":true,"touchRest":true,"lcVff":"split","lcTouch":{"reseed":true}}' /private/tmp/claude-501/-Users-zainrahman/8af3fa3f-f134-4178-b7ae-7855027dda6e/scratchpad/bm2/res/b_Pmin_V2-175-70_F30_dz0.json > /private/tmp/claude-501/-Users-zainrahman/8af3fa3f-f134-4178-b7ae-7855027dda6e/scratchpad/bm2/res/b_Pmin_V2-175-70_F30_dz0.log 2>&1
