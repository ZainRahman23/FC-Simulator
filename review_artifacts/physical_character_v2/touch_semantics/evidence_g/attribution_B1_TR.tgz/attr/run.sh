#!/bin/zsh
S=/private/tmp/claude-501/-Users-zainrahman/8af3fa3f-f134-4178-b7ae-7855027dda6e/scratchpad; T=$S/v4/tree; R=$T/review_artifacts/physical_character_v2; A=$S/v4/attr
cd $T/sandbox/visual/physchar2
# side jobs (background): boundary harness (V2-REF 240 Hz) and twist HO3 (V2-165-62, ref/current) per arm
for arm in base B1 TR; do case $arm in base) BS='{"ikRefTwist":true}'; XS='';; B1) BS='{"ikRefTwist":true,"ffLockedAxis":true}'; XS='{"ffLockedAxis":true}';; TR) BS='{"ikRefTwist":true,"touchRest":true}'; XS='{"touchRest":true}';; esac
  ( V2_KNEE_MODEL=v2k V2_ANKLE_NEUTRAL_K=0.13 node tools/boundary_probe.mjs --human=V2-REF --hz=240 --stand="$BS" $A/boundary_REF_$arm.json > $A/boundary_REF_$arm.log 2>&1 ) &
  for p in ref current; do ( V2_KNEE_MODEL=v2k V2_ANKLE_NEUTRAL_K=0.13 V2_XSTAND="$XS" node tools/twist_policy_battery.mjs --policy=$p --human=V2-165-62 --scen=HO3 $A/ho3_${p}_$arm.json > /dev/null 2> $A/ho3_${p}_$arm.log ) & done; done
# G2 full per arm (sequential; own worker pool)
for arm in B1 TR; do case $arm in B1) XS='{"ikRefTwist":true,"lifecycle":true,"ffLockedAxis":true}';; TR) XS='{"ikRefTwist":true,"lifecycle":true,"touchRest":true}';; esac
  ( export V2_KNEE_MODEL=v2k V2_ANKLE_NEUTRAL_K=0.13 V2_XSTAND=$XS; node tools/g2_run.js > $A/g2_$arm.log 2>&1 ); cp $R/g2/json/g2_results_xstand.json $A/g2_results_$arm.json; done
wait; touch $A/done
